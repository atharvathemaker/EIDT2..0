import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

# 1. Page Configuration
st.set_page_config(
    page_title="Smart Healthcare Command Center",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Color palettes (Muted earth tones, slate grays, soft blues, sage greens)
COLORS = {
    'primary': '#4A6984', # Soft blue
    'secondary': '#6B8E23', # Sage green
    'danger': '#B45F06', # Muted orange/red
    'warning': '#D4A017', # Muted gold
    'background': '#F4F6F6', # Slate gray-ish light
    'text': '#2C3E50',
    'muted': '#7F8C8D',
    'bars': ['#5D6D7E', '#73C6B6', '#F5B041', '#E74C3C', '#85929E']
}

# 2. Sidebar & Global Interactivity
st.sidebar.title("Command Center Controls")
st.sidebar.markdown("---")

transformation_active = st.sidebar.toggle("Activate Digital Transformation", value=False)
st.sidebar.markdown("*(Toggle to simulate AI-driven ecosystem ROI)*")

branches = ['Main Campus', 'North Wing', 'South Wing']
selected_branches = st.sidebar.multiselect(
    "Select Hospital Branch(es)",
    options=branches,
    default=branches
)

if not selected_branches:
    st.warning("Please select at least one hospital branch to view data.")
    st.stop()

# 3. Mock Data Generation
@st.cache_data
def generate_mock_data():
    np.random.seed(42)
    # 24-hour time series for Operations
    hours = [f"{i:02d}:00" for i in range(24)]
    
    # Financial ARPOB data (last 12 months)
    months = pd.date_range(end=datetime.today(), periods=12, freq='ME').strftime('%b %Y').tolist()
    
    return hours, months

hours, months = generate_mock_data()

# Logic to apply state based on transformation toggle
def get_metrics(is_transformed, num_branches):
    multiplier = num_branches / 3.0 # Scale volume-based metrics if needed, but we mostly care about rates
    
    if is_transformed:
        # Transformed State
        data = {
            'assessment_time': 12, # mins
            'alos': 3.2, # days
            'oope': 4500, # $
            'assessment_delta': -28,
            'alos_delta': -2.1,
            'oope_delta': -1500,
            'readmission_risk': 8, # %
            'clabsi': 0.2, # per 1000 days
            'vap': 0.1,
            'med_error': 0.5, # %
            'care_plan_adherence': 98, # %
            'pain_score_monitoring': 99, # %
            'bed_occupancy': 81, # %
            'nurse_ratio': 'Acuity-based (1:4 avg)',
            'tat_lab': [max(10, np.random.normal(30, 5)) for _ in range(24)], # mins
            'tat_rad': [max(15, np.random.normal(45, 8)) for _ in range(24)],
            'ot_utilization': 88, # %
            'ot_cancel': 2.1, # %
            'arpob': [np.random.normal(1200 + i*30, 50) for i in range(12)], # Increasing
            'ebitda': 22.5, # %
            'cmi': 1.85,
            'payer_mix': {'Cash': 20, 'Insurance': 65, 'Govt Schemes': 15},
            'doc_revenue': {'Top 5 Doctors': 35, 'Rest of Staff': 65},
            'nabh': 'Compliant (Automated Logs)',
            'abha': '98% Synced',
            'fhir': 'Active (HIE Connected)',
            'grievance_tat': 2, # hours
        }
    else:
        # Baseline State
        data = {
            'assessment_time': 40, # mins
            'alos': 5.3, # days
            'oope': 6000, # $
            'assessment_delta': 0,
            'alos_delta': 0,
            'oope_delta': 0,
            'readmission_risk': 24, # %
            'clabsi': 2.8, # per 1000 days
            'vap': 3.1,
            'med_error': 4.2, # %
            'care_plan_adherence': 65, # %
            'pain_score_monitoring': 70, # %
            'bed_occupancy': 94, # %
            'nurse_ratio': '1:10 (Static)',
            'tat_lab': [max(30, np.random.normal(120, 30)) for _ in range(24)],
            'tat_rad': [max(45, np.random.normal(180, 40)) for _ in range(24)],
            'ot_utilization': 65, # %
            'ot_cancel': 12.5, # %
            'arpob': [np.random.normal(850 + i*5, 30) for i in range(12)], # Stagnant
            'ebitda': 12.0, # %
            'cmi': 1.35,
            'payer_mix': {'Cash': 55, 'Insurance': 30, 'Govt Schemes': 15},
            'doc_revenue': {'Top 5 Doctors': 75, 'Rest of Staff': 25},
            'nabh': 'Manual Audit Required',
            'abha': '15% Synced (Manual)',
            'fhir': 'Siloed Data',
            'grievance_tat': 48, # hours
        }
    return data

metrics = get_metrics(transformation_active, len(selected_branches))

st.title("Smart Healthcare Command Center")
st.subheader("Enterprise Digital Transformation Dashboard")
st.markdown("---")

tab1, tab2, tab3, tab4 = st.tabs([
    "🩺 Patient Care", 
    "⚙️ Operations", 
    "💰 Financials", 
    "🛡️ Ecosystem & Compliance"
])

# --- TAB 1: Patient Care ---
with tab1:
    st.markdown("### Clinical Outcomes & Safety")
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric(
            "Initial Assessment Time", 
            f"{metrics['assessment_time']} mins", 
            f"{metrics['assessment_delta']} mins" if transformation_active else None,
            delta_color="inverse"
        )
    with col2:
        st.metric(
            "Average Length of Stay (ALOS)", 
            f"{metrics['alos']} days", 
            f"{metrics['alos_delta']} days" if transformation_active else None,
            delta_color="inverse"
        )
    with col3:
        oope_delta_str = None
        if transformation_active:
            sign = "-" if metrics['oope_delta'] < 0 else ""
            oope_delta_str = f"{sign}${abs(metrics['oope_delta'])}"
        st.metric(
            "Out-of-Pocket Expenditure (OOPE)", 
            f"${metrics['oope']}", 
            oope_delta_str,
            delta_color="inverse"
        )
        
    st.markdown("---")
    
    col_gauge, col_bar = st.columns([1, 1.5])
    
    with col_gauge:
        # Gauge Chart for Readmission Risk
        fig_gauge = go.Figure(go.Indicator(
            mode = "gauge+number",
            value = metrics['readmission_risk'],
            title = {'text': "30-Day Readmission Risk (%)", 'font': {'size': 18}},
            gauge = {
                'axis': {'range': [None, 100]},
                'bar': {'color': COLORS['primary'] if transformation_active else COLORS['danger']},
                'steps': [
                    {'range': [0, 15], 'color': "lightgray"},
                    {'range': [15, 50], 'color': "gray"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 20
                }
            }
        ))
        fig_gauge.update_layout(height=350, margin=dict(l=20, r=20, t=50, b=20))
        st.plotly_chart(fig_gauge, use_container_width=True)
        
    with col_bar:
        # Bar Chart for Infection Rates & Errors
        categories = ['CLABSI (per 1k days)', 'VAP (per 1k days)', 'Medication Errors (%)']
        values = [metrics['clabsi'], metrics['vap'], metrics['med_error']]
        
        fig_bar = px.bar(
            x=categories, 
            y=values, 
            text=values,
            color=categories,
            color_discrete_sequence=[COLORS['secondary'], COLORS['primary'], COLORS['muted']],
            labels={'x': 'Metric', 'y': 'Rate'}
        )
        fig_bar.update_traces(texttemplate='%{text:.1f}', textposition='outside')
        fig_bar.update_layout(
            title="Infection Control & Safety Incidents",
            showlegend=False,
            height=350,
            plot_bgcolor='rgba(0,0,0,0)'
        )
        st.plotly_chart(fig_bar, use_container_width=True)
        
    st.markdown("### Nursing Quality Indicators")
    col_nq1, col_nq2 = st.columns(2)
    with col_nq1:
        st.progress(metrics['care_plan_adherence'] / 100.0)
        st.markdown(f"**Nursing Care Plan Adherence:** {metrics['care_plan_adherence']}%")
    with col_nq2:
        st.progress(metrics['pain_score_monitoring'] / 100.0)
        st.markdown(f"**Pain Score Monitoring Compliance:** {metrics['pain_score_monitoring']}%")


# --- TAB 2: Operations ---
with tab2:
    st.markdown("### The Machine Room")
    
    col_op1, col_op2 = st.columns(2)
    with col_op1:
        st.markdown("#### Bed Occupancy Rate")
        # Custom progress-like display for Bed Occupancy
        occ = metrics['bed_occupancy']
        color = 'green' if 75 <= occ <= 85 else ('red' if occ > 90 else 'orange')
        
        fig_occ = go.Figure(go.Indicator(
            mode = "gauge+number",
            value = occ,
            number = {'suffix': "%"},
            gauge = {
                'axis': {'range': [None, 100]},
                'bar': {'color': color},
                'steps': [
                    {'range': [0, 75], 'color': "lightgray"},
                    {'range': [75, 85], 'color': "rgba(107, 142, 35, 0.4)"}, # Target zone
                    {'range': [85, 100], 'color': "lightgray"}
                ],
            }
        ))
        fig_occ.update_layout(height=250, margin=dict(l=20, r=20, t=30, b=20))
        st.plotly_chart(fig_occ, use_container_width=True)
        st.caption("Target: 75-85% for optimal operational efficiency.")

    with col_op2:
        st.markdown("#### Resource Utilization")
        st.info(f"**Nursing-to-Patient Ratio:** \n\n{metrics['nurse_ratio']}")
        
        st.metric("OT Utilization Rate", f"{metrics['ot_utilization']}%")
        st.metric("OT Cancellation Rate", f"{metrics['ot_cancel']}%", 
                  f"{- (12.5 - 2.1):.1f}%" if transformation_active else None, delta_color="inverse")
        
    st.markdown("---")
    st.markdown("#### Diagnostics Turnaround Time (TAT) - Last 24 Hours")
    
    df_tat = pd.DataFrame({
        'Hour': hours,
        'Lab TAT (mins)': metrics['tat_lab'],
        'Radiology TAT (mins)': metrics['tat_rad']
    })
    
    fig_tat = px.line(
        df_tat, 
        x='Hour', 
        y=['Lab TAT (mins)', 'Radiology TAT (mins)'],
        color_discrete_sequence=[COLORS['primary'], COLORS['secondary']],
        labels={'value': 'Turnaround Time (Minutes)', 'variable': 'Department'}
    )
    fig_tat.update_layout(plot_bgcolor='rgba(0,0,0,0)', hovermode='x unified')
    st.plotly_chart(fig_tat, use_container_width=True)


# --- TAB 3: Financials ---
with tab3:
    st.markdown("### The Investment Lens")
    
    col_fin1, col_fin2 = st.columns(2)
    with col_fin1:
        st.metric(
            "EBITDA Margin", 
            f"{metrics['ebitda']}%", 
            f"+{metrics['ebitda'] - 12.0:.1f}%" if transformation_active else None
        )
    with col_fin2:
        st.metric(
            "Case Mix Index (CMI)", 
            f"{metrics['cmi']:.2f}",
            f"+{metrics['cmi'] - 1.35:.2f}" if transformation_active else None
        )
        
    st.markdown("---")
    
    col_chart1, col_chart2 = st.columns(2)
    
    with col_chart1:
        st.markdown("#### Average Revenue Per Occupied Bed (ARPOB)")
        df_arpob = pd.DataFrame({
            'Month': months,
            'ARPOB ($)': metrics['arpob']
        })
        fig_arpob = px.line(
            df_arpob, x='Month', y='ARPOB ($)', markers=True,
            color_discrete_sequence=[COLORS['primary']]
        )
        fig_arpob.update_layout(plot_bgcolor='rgba(0,0,0,0)')
        st.plotly_chart(fig_arpob, use_container_width=True)
        
    with col_chart2:
        st.markdown("#### Payer Mix")
        payer_df = pd.DataFrame(list(metrics['payer_mix'].items()), columns=['Payer', 'Percentage'])
        fig_payer = px.pie(
            payer_df, values='Percentage', names='Payer', hole=0.5,
            color_discrete_sequence=[COLORS['secondary'], COLORS['primary'], COLORS['muted']]
        )
        st.plotly_chart(fig_payer, use_container_width=True)
        
    st.markdown("---")
    st.markdown("#### Doctor Revenue Concentration")
    doc_df = pd.DataFrame(list(metrics['doc_revenue'].items()), columns=['Group', 'Revenue Share (%)'])
    fig_doc = px.bar(
        doc_df, x='Revenue Share (%)', y='Group', orientation='h',
        color='Group', color_discrete_sequence=[COLORS['muted'], COLORS['primary']]
    )
    fig_doc.update_layout(showlegend=False, plot_bgcolor='rgba(0,0,0,0)', height=250)
    st.plotly_chart(fig_doc, use_container_width=True)


# --- TAB 4: Ecosystem & Compliance ---
with tab4:
    st.markdown("### Regulatory & Ecosystem Readiness")
    
    st.markdown("#### Compliance Status")
    
    def status_indicator(label, status, good_keyword):
        is_good = good_keyword.lower() in status.lower()
        color = "🟢" if is_good else "🔴"
        st.markdown(f"**{color} {label}:** {status}")

    status_indicator("NABH/JCI Accreditation", metrics['nabh'], "Compliant")
    status_indicator("ABHA (National Health ID) Sync", metrics['abha'], "98%")
    status_indicator("Cross-Hospital FHIR Data Sharing", metrics['fhir'], "Active")
    
    st.markdown("---")
    st.markdown("#### Patient Experience & Redressal")
    
    col_griev1, col_griev2 = st.columns([1, 2])
    with col_griev1:
        st.metric(
            "Grievance Redressal TAT", 
            f"{metrics['grievance_tat']} hours",
            f"{- (48 - metrics['grievance_tat'])} hours" if transformation_active else None,
            delta_color="inverse"
        )
    with col_griev2:
        if transformation_active:
            st.success("AI-driven NLP sentiment analysis and automated ticketing are highly active, routing complaints to the right departments instantly.")
        else:
            st.error("Manual review process in place. Multiple silos delay resolution and affect patient satisfaction scores.")

